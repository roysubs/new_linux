<https://github.com/tmewett/BrogueCE/wiki/Contribution-guide>
