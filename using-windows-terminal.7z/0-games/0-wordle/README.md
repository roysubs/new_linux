# wordle.sh
wordle but its bash !!! 
