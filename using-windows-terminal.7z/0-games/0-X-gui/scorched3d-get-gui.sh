#!/bin/bash

echo "A 3D artillery game with destructible terrain and multiplayer support."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install scorched3d

