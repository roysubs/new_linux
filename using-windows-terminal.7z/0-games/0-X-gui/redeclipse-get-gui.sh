#!/bin/bash

echo "A modern FPS with parkour elements and a variety of game modes."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install redeclipse

