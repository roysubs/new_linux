#!/bin/bash

echo "A strategy game inspired by Sid Meier's Colonization."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install freecol

