#!/bin/bash

echo "Open-source FPS with a strong multiplayer community and a built-in level editor."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install sauerbraten

