#!/bin/bash

echo "An open-source real-time strategy game focused on historical warfare and resource management."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install 0ad

