#!/bin/bash

echo "A realistic and open-source flight simulator."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install flightgear

