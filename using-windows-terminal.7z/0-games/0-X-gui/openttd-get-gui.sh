#!/bin/bash

echo "A transport and business simulation game inspired by the classic Transport Tycoon Deluxe."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install openttd

