#!/bin/bash

echo "A high-speed arena shooter with advanced graphics and active online play."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install xonotic

