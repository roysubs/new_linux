#!/bin/bash

echo "A fun, kart-racing game similar to Mario Kart, with a variety of tracks and characters from open-source projects."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install supertuxkart

