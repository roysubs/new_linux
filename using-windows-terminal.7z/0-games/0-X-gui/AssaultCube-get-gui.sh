#!/bin/bash

echo "A lightweight, fast-paced first-person shooter with both single-player and multiplayer modes."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install assaultcube

