#!/bin/bash

echo "A turn-based strategy game featuring fantasy battles and campaigns."
echo "Works well on WSL in Windows (with WSLg)"

sudo apt install wesnoth
