#!/bin/bash

echo "

How to play:
==========

Type 'guest' in the login section.
Then type 'getgame' to play, and type 'quit' to exit.
For more information go to:   freechess.org/QuickGuide

==========

"

telnet freechess.org 5000


