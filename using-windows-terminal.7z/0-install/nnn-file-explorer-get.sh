#!/bin/bash
sudo aps install nnn
