#!/bin/bash
./install-github-release.sh eza-community/eza 'eza.*x86_64.*linux.*\.tar\.gz' eza 
