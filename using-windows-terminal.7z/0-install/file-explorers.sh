sudo apt install lf   # Lightweight Go console file explorer
sudo apt install fdclone  # Two-pane console explorer (some Chinese characters)
