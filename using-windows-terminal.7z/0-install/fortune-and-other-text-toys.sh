#!/bin/bash

sudo apt install fortune cowsay toilet lolcat figlet
sudo apt install libaa-bin   # aafire (fireplace simulator)
# sudo snap install ponysay
sudo apt hollywood   # run to see randomised events 
sudo apt bb

echo "
Examples:

fortune | cowsay | lolcat
fortune | ponysay
echo "1234567890" | toilet | lolcat
showfigfonts   # show all fonts

"
